package string;

import java.util.Scanner;

public class Ch6Ex6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		String msg = scan.next();
		System.out.println("�Է�: " +msg);
		int num = scan.nextInt();
		System.out.println("�Է�: " +num);
	}

}
